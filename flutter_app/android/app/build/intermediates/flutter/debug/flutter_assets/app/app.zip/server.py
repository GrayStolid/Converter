import asyncio
import websockets
import json
from websockets.server import serve

# A set to keep track of all connected clients
CONNECTED_CLIENTS = set()

async def live_location_handler(websocket):
    """
    Handles a single client connection.
    """
    # 1. Add new client to the set
    CONNECTED_CLIENTS.add(websocket)
    print(f"Client connected: {websocket.remote_address}. Total clients: {len(CONNECTED_CLIENTS)}")

    try:
        # 2. Process incoming location messages
        async for message in websocket:
            print(f"Received location from {websocket.remote_address}: {message}")
            
            # --- Location Broadcast Logic ---
            # Parse the incoming JSON message
            try:
                location_data = json.loads(message)
                # You might want to add a unique ID or address to the message here
                location_data['source'] = str(websocket.remote_address)
                broadcast_message = json.dumps(location_data)
                
            except json.JSONDecodeError:
                print("Invalid JSON received.")
                continue

            # Send the location update to ALL other connected clients
            # This is how the 'live location' gets sent to the receiver device(s)
            
            # Create a copy of the set to iterate over in case of disconnects
            clients_to_send_to = list(CONNECTED_CLIENTS) 
            
            for client in clients_to_send_to:
                if client != websocket: # Don't send the message back to the sender
                    try:
                        await client.send(broadcast_message)
                    except websockets.exceptions.ConnectionClosed:
                        # Handle case where a client might have disconnected during iteration
                        pass
            
    except websockets.exceptions.ConnectionClosedOK:
        print(f"Client disconnected gracefully: {websocket.remote_address}")
    finally:
        # 3. Remove client when they disconnect
        CONNECTED_CLIENTS.remove(websocket)
        print(f"Client removed. Total clients: {len(CONNECTED_CLIENTS)}")


async def main():
    # To connect across devices, use "0.0.0.0" as the host.
    # Replace '8765' with your desired port.
    HOST = "0.0.0.0" 
    PORT = 8765
    
    print(f"Starting WebSocket server on ws://{HOST}:{PORT}")
    
    # Start the server and keep it running
    async with serve(live_location_handler, HOST, PORT):
        await asyncio.Future() # Run forever


if __name__ == "__main__":
    asyncio.run(main())