import asyncio
import websockets
import json
import time

# --- Configuration ---
# You MUST replace this with the IP address of the machine running server.py
# If running on the same computer, 'localhost' is fine.
SERVER_IP = "127.0.0.1" 
SERVER_PORT = 8765
URI = f"ws://{SERVER_IP}:{SERVER_PORT}"
# ---------------------

async def send_location(websocket):
    """
    Simulates getting and sending live location data.
    """
    # Dummy location data - in a real app, you'd use a GPS API here
    mock_latitude = 34.0522 
    mock_longitude = -118.2437
    
    # Simulate movement
    for i in range(10):
        # Update dummy location slightly
        current_lat = mock_latitude + (i * 0.0001)
        current_lon = mock_longitude + (i * 0.0002)
        
        # Prepare the message as a JSON string
        location_message = json.dumps({
            "latitude": current_lat,
            "longitude": current_lon,
            "timestamp": time.time()
        })
        
        # SEND the location to the server
        await websocket.send(location_message)
        print(f"Sent: {location_message}")
        
        # Wait for 1 second before sending the next update
        await asyncio.sleep(1)
        
    print("Location sending complete.")

async def receive_updates(websocket):
    """
    Listens for and processes location updates from other devices.
    """
    # Continuously listen for incoming messages
    async for message in websocket:
        print("-" * 30)
        print(f"Received Live Update: {message}")
        try:
            data = json.loads(message)
            print(f"  Source Device: {data.get('source', 'Unknown')}")
            print(f"  New Location: Lat {data['latitude']:.4f}, Lon {data['longitude']:.4f}")
        except json.JSONDecodeError:
            print("  Error: Could not decode received message.")
        print("-" * 30)


async def client_main():
    """
    Connects to the server and runs the send/receive tasks concurrently.
    """
    print(f"Attempting to connect to {URI}...")
    
    try:
        # Establish the persistent connection
        async with websockets.connect(URI) as websocket:
            print("Successfully connected!")
            
            # Run the sending and receiving tasks at the same time
            send_task = asyncio.create_task(send_location(websocket))
            receive_task = asyncio.create_task(receive_updates(websocket))
            
            # Wait for both tasks to complete (or for the connection to close)
            await asyncio.gather(send_task, receive_task)

    except ConnectionRefusedError:
        print(f"Connection refused. Ensure the server is running at {SERVER_IP}:{SERVER_PORT}.")
    except Exception as e:
        print(f"An error occurred: {e}")


if __name__ == "__main__":
    asyncio.run(client_main())